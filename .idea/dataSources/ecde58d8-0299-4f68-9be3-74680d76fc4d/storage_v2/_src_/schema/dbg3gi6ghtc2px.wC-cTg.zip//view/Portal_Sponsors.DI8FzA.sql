create definer = uwqxnypspa2bb@`%` view Portal_Sponsors as
select `dbg3gi6ghtc2px`.`Portal`.`Por_ID`                                                 AS `Por_ID`,
       concat('[', group_concat(distinct json_object('Spo_ID', `S`.`Spo_ID`, 'Spo_Name', `S`.`Spo_Name`, 'Spo_Logo',
                                                     `S`.`Spo_logo`) separator ','), ']') AS `Por_Sponsors`
from ((((`dbg3gi6ghtc2px`.`Portal` join `dbg3gi6ghtc2px`.`Portal_Challenges` `PC`
         on ((`dbg3gi6ghtc2px`.`Portal`.`Por_ID` = `PC`.`PC_Por_ID`))) join `dbg3gi6ghtc2px`.`Challenges` `C`
        on ((`PC`.`PC_Cha_ID` = `C`.`Cha_ID`))) join `dbg3gi6ghtc2px`.`Challenge_Sponsors` `CS`
       on ((`C`.`Cha_ID` = `CS`.`CS_Cha_ID`))) join `dbg3gi6ghtc2px`.`Sponsors` `S`
      on ((`CS`.`CS_Spo_ID` = `S`.`Spo_ID`)))
group by `dbg3gi6ghtc2px`.`Portal`.`Por_ID`
order by `dbg3gi6ghtc2px`.`Portal`.`Por_ID`;


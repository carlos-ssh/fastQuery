create definer = utoldtf78qili@`%` trigger updateParticipantStatus
    after update
    on Challenges
    for each row
BEGIN
	DECLARE _CPH_Hiring_Type TINYINT(1);
	DECLARE _DeliveryTime DATETIME;
    
	IF(NEW.Cha_Current_Phase != OLD.Cha_Current_Phase)
    THEN 
		IF((SELECT CPH_Phase_Num FROM Challenges_Phases WHERE CPH_ID=NEW.Cha_Current_Phase LIMIT 1) > (SELECT CPH_Phase_Num FROM Challenges_Phases WHERE CPH_ID=OLD.Cha_Current_Phase LIMIT 1))
        THEN 
			/* Si se avanzó de fase en el challenge */
            SELECT CPH_End_Delivery_date,CPH_Hiring_Type INTO _DeliveryTime,_CPH_Hiring_Type FROM Challenges_Phases WHERE CPH_ID=NEW.Cha_Current_Phase;
           
            /* Actualizar el estado de los participantes que si avanzaron de fase*/
            IF(_CPH_Hiring_Type = 0) 
            THEN
			/*SET @MSG ="Muchas felicidades has pasado de fase. Te recordamos que la fecha límite para entregar archivos y/o entregables es";*/
             UPDATE Registered_Participants SET RPA_Status_Date=_DeliveryTime, RPA_Status_Msg="Muchas felicidades por haber pasado de fase. Te recordamos que la fecha límite para entregar archivos y/o entregables es " WHERE RPA_Cha_ID=OLD.Cha_ID AND RPA_ID IN (SELECT PPRO_RPA_ID FROM Participant_Project WHERE PPRO_Current_CPH_ID = NEW.Cha_Current_Phase);
            
            ELSEIF (_CPH_Hiring_Type = 1) THEN
			/*SET @MSG ="Muchas felicidades has pasado de fase. Te recordamos que debes agendar una cita en el apartado 'administrar reto'";*/
			UPDATE Registered_Participants SET RPA_Status_Msg="Muchas felicidades por haber pasado de fase. Te recordamos que debes agendar una cita en el apartado 'administrar reto'" WHERE RPA_Cha_ID=OLD.Cha_ID AND RPA_ID IN (SELECT PPRO_RPA_ID FROM Participant_Project WHERE PPRO_Current_CPH_ID = NEW.Cha_Current_Phase);

			ELSEIF (_CPH_Hiring_Type = 2) THEN
			 /*SET @MSG ="Muchas felicidades has pasado de fase. Te recordamos que debes realizar el test antes de ";*/
			 UPDATE Registered_Participants SET RPA_Status_Date=_DeliveryTime,  RPA_Status_Msg="Muchas felicidades por haber pasado de fase. Te recordamos que debes realizar el test antes de " WHERE RPA_Cha_ID=OLD.Cha_ID AND RPA_ID IN (SELECT PPRO_RPA_ID FROM Participant_Project WHERE PPRO_Current_CPH_ID = NEW.Cha_Current_Phase);
           END IF;
            /* Actualizar el estado de los participantes que no han avanzado  */		
            UPDATE Registered_Participants SET RPA_Status_Date=null, RPA_Status_Msg="Sentimos informarte que no has pasado a la siguiente fase. Gracias por tu participación en el challenge" WHERE RPA_Cha_ID=OLD.Cha_ID AND RPA_ID IN (SELECT PPRO_RPA_ID FROM Participant_Project WHERE PPRO_Current_CPH_ID != NEW.Cha_Current_Phase);
        END IF;
    END IF;
END;


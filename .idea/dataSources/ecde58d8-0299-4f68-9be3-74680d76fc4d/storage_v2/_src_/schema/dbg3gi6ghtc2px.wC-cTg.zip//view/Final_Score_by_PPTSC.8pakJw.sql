create definer = utoldtf78qili@`%` view Final_Score_by_PPTSC as
select `dbg3gi6ghtc2px`.`Score_Assigned`.`SASS_PPTSC_ID`                                                      AS `SASS_PPTSC_ID`,
       `dbg3gi6ghtc2px`.`Score_Assigned`.`SASS_PPRO_ID`                                                       AS `SASS_PPRO_ID`,
       `PPtS`.`PPTSC_CPH_ID`                                                                                  AS `PPTSC_CPH_ID`,
       avg(`dbg3gi6ghtc2px`.`Score_Assigned`.`SASS_Score`)                                                    AS `AVG_Score`,
       `PPtS`.`PPTSC_Score_weight_Percentage`                                                                 AS `PPTSC_Score_weight_Percentage`,
       ((avg(`dbg3gi6ghtc2px`.`Score_Assigned`.`SASS_Score`) * `PPtS`.`PPTSC_Score_weight_Percentage`) /
        100)                                                                                                  AS `FINAL_SCORE`
from (`dbg3gi6ghtc2px`.`Score_Assigned` join `dbg3gi6ghtc2px`.`Phase_Points_to_Score` `PPtS`
      on ((`dbg3gi6ghtc2px`.`Score_Assigned`.`SASS_PPTSC_ID` = `PPtS`.`PPTSC_ID`)))
group by `dbg3gi6ghtc2px`.`Score_Assigned`.`SASS_PPTSC_ID`, `dbg3gi6ghtc2px`.`Score_Assigned`.`SASS_PPRO_ID`;


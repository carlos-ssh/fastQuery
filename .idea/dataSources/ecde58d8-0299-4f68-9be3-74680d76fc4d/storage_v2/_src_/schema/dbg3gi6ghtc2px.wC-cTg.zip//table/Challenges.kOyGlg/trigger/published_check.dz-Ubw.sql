create definer = utoldtf78qili@`%` trigger published_check
    before update
    on Challenges
    for each row
BEGIN
    IF ((ISNULL(@TRIGGER_BEFORE_UPDATE_CHECKS) OR @TRIGGER_BEFORE_UPDATE_CHECKS = 1) AND OLD.Cha_isPublished = 1)  THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'El Challenge ya fue publicado y esta acción no se puede revertir',MYSQL_ERRNO = 400 ;
    END IF;
END;


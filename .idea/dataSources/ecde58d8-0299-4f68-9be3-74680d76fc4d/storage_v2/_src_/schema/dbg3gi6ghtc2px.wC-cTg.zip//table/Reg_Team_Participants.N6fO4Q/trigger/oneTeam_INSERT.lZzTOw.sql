create definer = utoldtf78qili@`%` trigger oneTeam_INSERT
    before insert
    on Reg_Team_Participants
    for each row
BEGIN
        DECLARE _isFull BOOLEAN;
        IF( EXISTS(
                SELECT *
                FROM Reg_Team_Participants
                WHERE RTP_Part_ID = NEW.RTP_Part_ID
                  AND RTP_Cha_ID = NEW.RTP_Cha_ID
                  AND RTP_Status = 1) AND NEW.RTP_Status = 1) THEN
                SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = "Ya estas en un equipo" ,MYSQL_ERRNO = 400;
        END IF;
        SET _isFull = (SELECT RTE_isFull from Registered_Teams WHERE RTE_Cha_ID = NEW.RTP_Cha_ID AND RTE_Team_ID = NEW.RTP_Team_ID LIMIT 1);
        IF(_isFull) THEN
            SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = "Ya esta completo el equipo" ,MYSQL_ERRNO = 400;
        ELSE IF(NEW.RTP_Status = 1) THEN
            UPDATE Registered_Teams
            SET RTE_Part_Count=RTE_Part_Count+1
            WHERE RTE_Team_ID=NEW.RTP_Team_ID AND RTE_Cha_ID=NEW.RTP_Cha_ID;
        END IF;
    END IF;
end;


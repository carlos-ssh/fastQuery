create definer = uwqxnypspa2bb@`%` view Report_Projects_Deliveries as
select `dbg3gi6ghtc2px`.`Participant_Project`.`PPRO_ID`          AS `PPRO_ID`,
       `dbg3gi6ghtc2px`.`Participant_Project`.`PPRO_Category`    AS `PPRO_Category`,
       `dbg3gi6ghtc2px`.`Participant_Project`.`PPRO_Title`       AS `PPRO_Title`,
       `dbg3gi6ghtc2px`.`Participant_Project`.`PPRO_Cha_ID`      AS `PPRO_Cha_ID`,
       `dbg3gi6ghtc2px`.`Participant_Project`.`PPRO_Description` AS `PPRO_Description`,
       `dbg3gi6ghtc2px`.`Participant_Project`.`PPRO_Image`       AS `PPRO_Image`,
       `dbg3gi6ghtc2px`.`Participant_Project`.`PPRO_Team_ID`     AS `PPRO_Team_ID`,
       concat(`TII`.`TIN_Name`, ' ', `TII`.`TIN_Last_Name`)      AS `Part_Name`,
       `TI`.`TID_Email`                                          AS `Part_Email`,
       if((`PRD`.`PRDE_Name` is not null), concat('[', group_concat(json_object(if((`PRD`.`PRDE_Name` is not null),
                                                                                   concat('Fase ', `CP`.`CPH_Phase_Num`, ': ', `PRD`.`PRDE_Name`),
                                                                                   ''), `PD`.`PDE_File`) separator ','),
                                                  ']'), NULL)    AS `Project_Deliveries_JSON`
from (((((((`dbg3gi6ghtc2px`.`Participant_Project` left join `dbg3gi6ghtc2px`.`Participant_Delivery` `PD`
            on ((`dbg3gi6ghtc2px`.`Participant_Project`.`PPRO_ID` = `PD`.`PDE_PPRO_ID`))) left join `dbg3gi6ghtc2px`.`Phase_Requesed_Deliveries` `PRD`
           on ((`PD`.`PDE_PRDE_ID` = `PRD`.`PRDE_ID`))) left join `dbg3gi6ghtc2px`.`Challenges_Phases` `CP`
          on ((`PRD`.`PRDE_CPH_ID` = `CP`.`CPH_ID`))) left join `dbg3gi6ghtc2px`.`Registered_Participants` `RPA`
         on ((`RPA`.`RPA_ID` = `dbg3gi6ghtc2px`.`Participant_Project`.`PPRO_RPA_ID`))) left join `dbg3gi6ghtc2px`.`Participants` `P`
        on ((`RPA`.`RPA_Part_ID` = `P`.`Part_ID`))) left join `dbg3gi6ghtc2px`.`TalentID` `TI`
       on ((`P`.`Part_Talent_ID` = `TI`.`TID_TalentID`))) left join `dbg3gi6ghtc2px`.`TalentId_Info` `TII`
      on ((`TI`.`TID_TalentID` = `TII`.`TIN_TID_ID`)))
group by `dbg3gi6ghtc2px`.`Participant_Project`.`PPRO_Cha_ID`, `dbg3gi6ghtc2px`.`Participant_Project`.`PPRO_ID`;

-- comment on column Report_Projects_Deliveries.PPRO_Team_ID not supported: PENDIENTE


create definer = uwqxnypspa2bb@`%` view Report_Teams as
select `Teams_Basic`.`Team_Name`                                                                                 AS `Team_Name`,
       `Teams_Basic`.`Team_ID`                                                                                   AS `Team_ID`,
       `Teams_Basic`.`RTE_Cha_ID`                                                                                AS `RTE_Cha_ID`,
       `Teams_Basic`.`RTE_JoinedAt`                                                                              AS `RTE_JoinedAt`,
       `Teams_Basic`.`Team_CreatedAt`                                                                            AS `Team_CreatedAt`,
       `Teams_Basic`.`Team_Description`                                                                          AS `Team_Description`,
       `Teams_Basic`.`RTE_Part_Count`                                                                            AS `RTE_Part_Count`,
       `Teams_Basic`.`RPA_ID`                                                                                    AS `RPA_ID`,
       `Teams_Basic`.`Team_Image`                                                                                AS `Team_Image`,
       `Teams_Basic`.`Team_Leader`                                                                               AS `Team_Leader`,
       `Teams_Basic`.`Leader_Name`                                                                               AS `Leader_Name`,
       `Teams_Basic`.`Leader_Email`                                                                              AS `Leader_Email`,
       `Teams_Basic`.`Leader_Info_Json`                                                                          AS `Leader_Info_Json`,
       count(distinct `P2`.`Part_ID`)                                                                            AS `Real_Members_Count`,
       concat('[', group_concat(
               json_object('Member_Name', concat(`TIN2`.`TIN_Name`, ' ', `TIN2`.`TIN_Last_Name`), 'Member_Email',
                           `TIN2`.`TIN_Email`, 'Member_IsLeader',
                           if((`P2`.`Part_ID` = `Teams_Basic`.`Team_Leader`), TRUE, FALSE)) separator ','),
              ']')                                                                                               AS `Team_Members_Json`
from (((((select `T`.`Team_Name`                                      AS `Team_Name`,
                 `T`.`Team_ID`                                        AS `Team_ID`,
                 `dbg3gi6ghtc2px`.`Registered_Teams`.`RTE_Cha_ID`     AS `RTE_Cha_ID`,
                 `dbg3gi6ghtc2px`.`Registered_Teams`.`RTE_JoinedAt`   AS `RTE_JoinedAt`,
                 `T`.`Team_CreatedAt`                                 AS `Team_CreatedAt`,
                 `T`.`Team_Description`                               AS `Team_Description`,
                 `dbg3gi6ghtc2px`.`Registered_Teams`.`RTE_Part_Count` AS `RTE_Part_Count`,
                 `RP`.`RPA_ID`                                        AS `RPA_ID`,
                 `T`.`Team_Image`                                     AS `Team_Image`,
                 concat(`TIN`.`TIN_Name`, ' ', `TIN`.`TIN_Last_Name`) AS `Leader_Name`,
                 `TIN`.`TIN_Email`                                    AS `Leader_Email`,
                 `T`.`Team_Leader`                                    AS `Team_Leader`,
                 concat('[', group_concat(
                         if(isnull(`CAI`.`CAI_Name`), NULL, json_object(`CAI`.`CAI_Name`, `PAI`.`PAI_FieldValue`))
                         separator ','), ']')                         AS `Leader_Info_Json`
          from ((((((`dbg3gi6ghtc2px`.`Registered_Teams` join `dbg3gi6ghtc2px`.`Teams` `T`
                     on ((`dbg3gi6ghtc2px`.`Registered_Teams`.`RTE_Team_ID` = `T`.`Team_ID`))) join `dbg3gi6ghtc2px`.`Participants` `P`
                    on ((`T`.`Team_Leader` = `P`.`Part_ID`))) join `dbg3gi6ghtc2px`.`TalentId_Info` `TIN`
                   on ((`TIN`.`TIN_TID_ID` = `P`.`Part_Talent_ID`))) join `dbg3gi6ghtc2px`.`Registered_Participants` `RP`
                  on (((`P`.`Part_ID` = `RP`.`RPA_Part_ID`) and
                       (`RP`.`RPA_Cha_ID` = `dbg3gi6ghtc2px`.`Registered_Teams`.`RTE_Cha_ID`)))) left join `dbg3gi6ghtc2px`.`Participant_Aditional_Info` `PAI`
                 on ((`RP`.`RPA_ID` = `PAI`.`PAI_RP_ID`))) left join `dbg3gi6ghtc2px`.`Challenge_Aditional_Info` `CAI`
                on ((`PAI`.`PAI_CAI_ID` = `CAI`.`CAI_ID`)))
          group by `RP`.`RPA_ID`)) `Teams_Basic` join `dbg3gi6ghtc2px`.`Reg_Team_Participants` `RTP`
        on (((`RTP`.`RTP_Team_ID` = `Teams_Basic`.`Team_ID`) and
             (`RTP`.`RTP_Cha_ID` = `Teams_Basic`.`RTE_Cha_ID`)))) join `dbg3gi6ghtc2px`.`Participants` `P2`
       on ((`RTP`.`RTP_Part_ID` = `P2`.`Part_ID`))) join `dbg3gi6ghtc2px`.`TalentId_Info` `TIN2`
      on ((`TIN2`.`TIN_TID_ID` = `P2`.`Part_Talent_ID`)))
group by `Teams_Basic`.`RTE_Cha_ID`, `Teams_Basic`.`Team_ID`;


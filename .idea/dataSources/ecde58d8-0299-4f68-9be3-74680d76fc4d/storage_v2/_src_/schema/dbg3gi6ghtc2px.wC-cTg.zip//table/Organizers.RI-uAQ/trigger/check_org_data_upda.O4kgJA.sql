create definer = uwqxnypspa2bb@`%` trigger check_org_data_upda
    before update
    on Organizers
    for each row
BEGIN
    /* Verifica que el nombre de la organizacion que se va a actualizar no se repita a nivel de GA (cuando Org_ParentOrganizer=NULL)
       ó dentro de la Organizacion de la que es hija (cuando Org_ParentOrganizer hace referencia a una organizacion Padre)*/
 
    IF(NEW.Org_ParentOrganizer IS NULL) THEN
        IF(EXISTS(SELECT * FROM Organizers WHERE  Org_ID!=OLD.Org_ID AND Org_ParentOrganizer IS NULL  AND Org_Name=NEW.Org_Name AND Org_Status='1')) THEN
            SIGNAL SQLSTATE '23000' SET MESSAGE_TEXT = 'Duplicate org name', MYSQL_ERRNO = 400 ;
        END IF;
    ELSEIF(NEW.Org_ParentOrganizer IS NOT NULL) THEN
        IF(EXISTS(SELECT * FROM Organizers WHERE Org_ID!=OLD.Org_ID AND Org_ParentOrganizer=NEW.Org_ParentOrganizer  AND Org_Name=NEW.Org_Name AND Org_Status='1')) THEN
            SIGNAL SQLSTATE '23000' SET MESSAGE_TEXT = 'Duplicate org name', MYSQL_ERRNO = 400 ;
        END IF;
    END IF;

    /* Verifica que solo una organizacion 'padre' puede tener sub-organizaciones asociadas.
       Una sub-organizxacion no puede tener organizaciones 'hijas'
       */
    IF(NEW.Org_ParentOrganizer IS NOT NULL) THEN
        IF((SELECT Org_ParentOrganizer FROM Organizers WHERE Org_ID=NEW.Org_ParentOrganizer LIMIT 1) IS NOT NULL) THEN
            SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Not allowed ', MYSQL_ERRNO =403;
        END IF;
    END IF;
END;


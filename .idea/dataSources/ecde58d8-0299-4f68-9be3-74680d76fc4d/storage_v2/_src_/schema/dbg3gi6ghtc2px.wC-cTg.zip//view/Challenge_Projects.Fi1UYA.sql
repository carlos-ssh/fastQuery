create definer = uwqxnypspa2bb@`%` view Challenge_Projects as
select `t`.`PPRO_ID`                                                          AS `PPRO_ID`,
       `t`.`PPRO_RPA_ID`                                                      AS `PPRO_RPA_ID`,
       `t`.`PPRO_Title`                                                       AS `PPRO_Title`,
       `t`.`PPRO_Image`                                                       AS `PPRO_Image`,
       `t`.`PPRO_Description`                                                 AS `PPRO_Description`,
       `t`.`CCA_Name`                                                         AS `CCA_Name`,
       `t`.`Team_ID`                                                          AS `Team_ID`,
       `t`.`Team_Name`                                                        AS `Team_Name`,
       `t`.`CPH_Phase_Num`                                                    AS `CPH_Phase_Num`,
       `t`.`PPRO_Cha_ID`                                                      AS `PPRO_Cha_ID`,
       `t`.`PPRO_Current_CPH_ID`                                              AS `PPRO_Current_CPH_ID`,
       `t`.`Members_Json`                                                     AS `Members_Json`,
       if((`TA`.`TA_Part_ID` is not null), concat('[', group_concat(
               json_object('TIN_Name', `TIN2`.`TIN_Name`, 'TIN_Last_Name', `TIN2`.`TIN_Last_Name`, 'TIN_Username',
                           `TIN2`.`TIN_Username`, 'TIN_Photo', `TIN2`.`TIN_Photo`, 'TID_TalentID',
                           `TID2`.`TID_TalentID`) separator ','), ']'), NULL) AS `Assessors_Json`
from (((((select `PP`.`PPRO_ID`             AS `PPRO_ID`,
                 `PP`.`PPRO_RPA_ID`         AS `PPRO_RPA_ID`,
                 `PP`.`PPRO_Title`          AS `PPRO_Title`,
                 `PP`.`PPRO_Image`          AS `PPRO_Image`,
                 `PP`.`PPRO_Description`    AS `PPRO_Description`,
                 `CC`.`CCA_Name`            AS `CCA_Name`,
                 `T`.`Team_ID`              AS `Team_ID`,
                 `T`.`Team_Name`            AS `Team_Name`,
                 `PP`.`PPRO_Cha_ID`         AS `PPRO_Cha_ID`,
                 `CP`.`CPH_Phase_Num`       AS `CPH_Phase_Num`,
                 `PP`.`PPRO_Current_CPH_ID` AS `PPRO_Current_CPH_ID`,
                 if((`RTP`.`RTP_Part_ID` is not null), concat('[', group_concat(
                         json_object('TIN_Name', `TII`.`TIN_Name`, 'TIN_Last_Name', `TII`.`TIN_Last_Name`,
                                     'TIN_Username', `TII`.`TIN_Username`, 'IsLeader',
                                     if((`RTP`.`RTP_Part_ID` = `T`.`Team_Leader`), TRUE, FALSE), 'TIN_Photo',
                                     `TII`.`TIN_Photo`, 'TID_TalentID', `TI`.`TID_TalentID`) separator ','), ']'),
                    NULL)                   AS `Members_Json`
          from (((((((`dbg3gi6ghtc2px`.`Participant_Project` `PP` join `dbg3gi6ghtc2px`.`Challenges_Phases` `CP`
                      on ((`PP`.`PPRO_Current_CPH_ID` = `CP`.`CPH_ID`))) left join `dbg3gi6ghtc2px`.`Challenge_Categories` `CC`
                     on ((`PP`.`PPRO_Category` = `CC`.`CCA_ID`))) left join `dbg3gi6ghtc2px`.`Teams` `T`
                    on ((`T`.`Team_ID` = `PP`.`PPRO_Team_ID`))) left join `dbg3gi6ghtc2px`.`Reg_Team_Participants` `RTP`
                   on (((`RTP`.`RTP_Team_ID` = `T`.`Team_ID`) and
                        (`RTP`.`RTP_Cha_ID` = `PP`.`PPRO_Cha_ID`)))) left join `dbg3gi6ghtc2px`.`Participants` `P`
                  on ((`RTP`.`RTP_Part_ID` = `P`.`Part_ID`))) left join `dbg3gi6ghtc2px`.`TalentID` `TI`
                 on ((`P`.`Part_Talent_ID` = `TI`.`TID_TalentID`))) left join `dbg3gi6ghtc2px`.`TalentId_Info` `TII`
                on ((`TI`.`TID_TalentID` = `TII`.`TIN_TID_ID`)))
          group by `PP`.`PPRO_ID`) `t` left join `dbg3gi6ghtc2px`.`Team_Assessor` `TA`
         on (((`t`.`Team_ID` = `TA`.`TA_Team_ID`) and
              (`TA`.`TA_Cha_ID` = `t`.`PPRO_Cha_ID`)))) left join `dbg3gi6ghtc2px`.`Participants` `P2`
        on ((`P2`.`Part_ID` = `TA`.`TA_Part_ID`))) left join `dbg3gi6ghtc2px`.`TalentID` `TID2`
       on ((`TID2`.`TID_TalentID` = `P2`.`Part_Talent_ID`))) left join `dbg3gi6ghtc2px`.`TalentId_Info` `TIN2`
      on ((`TIN2`.`TIN_TID_ID` = `TID2`.`TID_TalentID`)))
group by `t`.`PPRO_ID`;


create definer = utoldtf78qili@`%` trigger substract_deleted_part
    before delete
    on Reg_Team_Participants
    for each row
BEGIN
        UPDATE Registered_Teams
        SET RTE_Part_Count=RTE_Part_Count-1
        WHERE RTE_Team_ID=OLD.RTP_Team_ID AND RTE_Cha_ID=OLD.RTP_Cha_ID;
end;


create definer = utoldtf78qili@`%` trigger isFull
    before update
    on Registered_Teams
    for each row
BEGIN
        DECLARE _Cha_Team_MaxMembers tinyint(2) unsigned;
        SET _Cha_Team_MaxMembers = (SELECT Cha_Team_MaxMembers FROM Challenges WHERE Cha_ID = NEW.RTE_Cha_ID);
            IF(NEW.RTE_Part_Count < _Cha_Team_MaxMembers) THEN
                SET NEW.RTE_isFull = FALSE;
            ELSE
                SET NEW.RTE_isFull = TRUE;
            end if;
    end;


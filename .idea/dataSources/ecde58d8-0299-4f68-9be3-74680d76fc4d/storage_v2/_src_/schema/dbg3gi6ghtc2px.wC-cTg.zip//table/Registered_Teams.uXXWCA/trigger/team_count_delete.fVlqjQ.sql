create definer = utoldtf78qili@`%` trigger team_count_delete
    before delete
    on Registered_Teams
    for each row
BEGIN
    UPDATE Challenges SET Cha_RTE_Count=Cha_RTE_Count-1, Cha_isFull=IF(Cha_RTE_Count-1 < Cha_Max_Teams, false,true) WHERE Cha_ID = OLD.RTE_Cha_ID;
end;


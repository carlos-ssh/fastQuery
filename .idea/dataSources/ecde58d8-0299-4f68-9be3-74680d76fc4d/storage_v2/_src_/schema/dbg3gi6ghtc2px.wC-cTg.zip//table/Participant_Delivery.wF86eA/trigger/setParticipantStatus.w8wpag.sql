create definer = utoldtf78qili@`%` trigger setParticipantStatus
    after insert
    on Participant_Delivery
    for each row
BEGIN
/* Actualiza el estado del prticipante dependiendo de si ya subió todos sus entregables o no*/
	DECLARE _CPH_ID BIGINT(20) UNSIGNED;
    DECLARE _CPH_End_Delivery DATETIME DEFAULT NULL;
    
	SELECT PRDE_CPH_ID, CPH_End_Delivery_date INTO _CPH_ID, _CPH_End_Delivery FROM Phase_Requesed_Deliveries INNER JOIN Challenges_Phases ON Challenges_Phases.CPH_ID=PRDE_CPH_ID WHERE PRDE_ID=NEW.PDE_PRDE_ID;
    SET @ACTUAL_TOTAL_PART=(SELECT COUNT(*) FROM Participant_Delivery INNER JOIN Phase_Requesed_Deliveries ON PRDE_ID=PDE_PRDE_ID WHERE PRDE_CPH_ID=_CPH_ID AND PDE_RPA_ID=NEW.PDE_RPA_ID);
    SET @MAX_REQUESTED=( SELECT COUNT(*) FROM Phase_Requesed_Deliveries WHERE PRDE_CPH_ID=_CPH_ID);
   
    IF (@ACTUAL_TOTAL_PART >= @MAX_REQUESTED)
    THEN
		SET @MSG="Has entregado todos tus entregables, por favor espera tu evaluación";
        SET _CPH_End_Delivery=null;
    ELSE
		SET @MSG="Recuerda que tienes que subir los archivos/entregables requeridos. La fecha límite es ";
    END IF;
    UPDATE Registered_Participants SET RPA_Status_Msg=@MSG, RPA_Status_Date=_CPH_End_Delivery WHERE RPA_ID=NEW.PDE_RPA_ID;

END;


create definer = utoldtf78qili@`%` trigger part_count_delete
    before delete
    on Registered_Participants
    for each row
BEGIN
    UPDATE Challenges SET Cha_RPA_Count=IF(Cha_RPA_Count-1 = 0, 0,Cha_RPA_Count-1), Cha_isFull=IF(Cha_RPA_Count-1 < Cha_Max_Participants, false,true) WHERE Cha_ID = OLD.RPA_Cha_ID;
end;


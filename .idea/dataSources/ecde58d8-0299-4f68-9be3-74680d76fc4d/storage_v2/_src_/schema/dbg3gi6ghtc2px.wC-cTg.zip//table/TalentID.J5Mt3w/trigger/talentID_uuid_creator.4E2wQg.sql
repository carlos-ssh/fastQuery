create definer = utoldtf78qili@`%` trigger talentID_uuid_creator
    before insert
    on TalentID
    for each row
    SET new.TID_TalentID = (uuid());


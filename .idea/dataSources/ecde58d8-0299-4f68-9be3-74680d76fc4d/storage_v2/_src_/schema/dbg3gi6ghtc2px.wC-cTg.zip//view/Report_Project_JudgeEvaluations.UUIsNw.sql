create definer = uwqxnypspa2bb@`%` view Report_Project_JudgeEvaluations as
select `t`.`PPRO_ID`                                                                        AS `PPRO_ID`,
       `t`.`MAEV_CPH_ID`                                                                    AS `MAEV_CPH_ID`,
       `t`.`PPRO_Title`                                                                     AS `PPRO_Title`,
       `t`.`Team`                                                                           AS `Team`,
       `t`.`Participant`                                                                    AS `Participant`,
       (sum(json_extract(`t`.`Mentor_Detail`, '$.AVG')) / count(distinct `t`.`SASS_RM_ID`)) AS `Total_Score`,
       concat('[', group_concat(`t`.`Mentor_Detail` separator ','), ']')                    AS `Mentors_Evaluations_JSON`
from (select `PP`.`PPRO_ID`                                                                                       AS `PPRO_ID`,
             `dbg3gi6ghtc2px`.`Mentor_Assigned_Evaluation`.`MAEV_CPH_ID`                                          AS `MAEV_CPH_ID`,
             `PP`.`PPRO_Title`                                                                                    AS `PPRO_Title`,
             if(isnull(`T`.`Team_Name`), NULL, `T`.`Team_Name`)                                                   AS `Team`,
             if(isnull(`TIDII`.`TID_TalentID`), NULL,
                concat(`TINII`.`TIN_Name`, ' ', `TINII`.`TIN_Last_Name`))                                         AS `Participant`,
             `dbg3gi6ghtc2px`.`Score_Assigned`.`SASS_RM_ID`                                                       AS `SASS_RM_ID`,
             json_object('AVG', sum(ceiling((
                     (`dbg3gi6ghtc2px`.`Score_Assigned`.`SASS_Score` * `PPtS`.`PPTSC_Score_weight_Percentage`) / 100))),
                         'Email', `TI`.`TID_Email`, 'Name',
                         concat(`TII`.`TIN_Name`, ' ', `TII`.`TIN_Last_Name`))                                    AS `Mentor_Detail`
      from (((((((((((`dbg3gi6ghtc2px`.`Mentor_Assigned_Evaluation` join `dbg3gi6ghtc2px`.`Participant_Project` `PP`
                      on ((`dbg3gi6ghtc2px`.`Mentor_Assigned_Evaluation`.`MAEV_PPRO_ID` =
                           `PP`.`PPRO_ID`))) join `dbg3gi6ghtc2px`.`Registered_Mentors` `RM`
                     on ((`dbg3gi6ghtc2px`.`Mentor_Assigned_Evaluation`.`MAEV_RM_ID` =
                          `RM`.`RM_ID`))) join `dbg3gi6ghtc2px`.`TalentID` `TI`
                    on ((`RM`.`RM_Talent_ID` = `TI`.`TID_TalentID`))) join `dbg3gi6ghtc2px`.`TalentId_Info` `TII`
                   on ((`TI`.`TID_TalentID` = `TII`.`TIN_TID_ID`))) left join `dbg3gi6ghtc2px`.`Score_Assigned`
                  on (((`dbg3gi6ghtc2px`.`Score_Assigned`.`SASS_RM_ID` =
                        `dbg3gi6ghtc2px`.`Mentor_Assigned_Evaluation`.`MAEV_RM_ID`) and
                       (`dbg3gi6ghtc2px`.`Score_Assigned`.`SASS_PPRO_ID` =
                        `dbg3gi6ghtc2px`.`Mentor_Assigned_Evaluation`.`MAEV_PPRO_ID`) and
                       (`dbg3gi6ghtc2px`.`Score_Assigned`.`SASS_CPH` =
                        `dbg3gi6ghtc2px`.`Mentor_Assigned_Evaluation`.`MAEV_CPH_ID`)))) left join `dbg3gi6ghtc2px`.`Phase_Points_to_Score` `PPtS`
                 on ((`dbg3gi6ghtc2px`.`Score_Assigned`.`SASS_PPTSC_ID` = `PPtS`.`PPTSC_ID`))) left join `dbg3gi6ghtc2px`.`Teams` `T`
                on ((`T`.`Team_ID` = `PP`.`PPRO_Team_ID`))) left join `dbg3gi6ghtc2px`.`Registered_Participants` `RP`
               on ((`PP`.`PPRO_RPA_ID` = `RP`.`RPA_ID`))) left join `dbg3gi6ghtc2px`.`Participants` `P`
              on ((`RP`.`RPA_Part_ID` = `P`.`Part_ID`))) left join `dbg3gi6ghtc2px`.`TalentID` `TIDII`
             on ((`TIDII`.`TID_TalentID` = `P`.`Part_Talent_ID`))) left join `dbg3gi6ghtc2px`.`TalentId_Info` `TINII`
            on ((`TINII`.`TIN_TID_ID` = `TIDII`.`TID_TalentID`)))
      group by `dbg3gi6ghtc2px`.`Mentor_Assigned_Evaluation`.`MAEV_CPH_ID`,
               `dbg3gi6ghtc2px`.`Mentor_Assigned_Evaluation`.`MAEV_PPRO_ID`,
               `dbg3gi6ghtc2px`.`Mentor_Assigned_Evaluation`.`MAEV_RM_ID`) `t`
group by `t`.`MAEV_CPH_ID`, `t`.`PPRO_ID`;


create definer = utoldtf78qili@`%` trigger team_count
    before insert
    on Registered_Teams
    for each row
BEGIN
    DECLARE _isFull BOOLEAN;
    SET _isFull = (SELECT Cha_isFull from Challenges WHERE Cha_ID = NEW.RTE_Cha_ID LIMIT 1);
    IF(_isFull) THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = "YA NO HAY CUPO DE EQUIPOS" ,MYSQL_ERRNO = 400;
    ELSE
        UPDATE Challenges SET Cha_RTE_Count=Cha_RTE_Count+1, Cha_isFull=IF(Cha_RTE_Count < Cha_Max_Teams, false,true) WHERE Cha_ID = NEW.RTE_Cha_ID;
    end if;
end;


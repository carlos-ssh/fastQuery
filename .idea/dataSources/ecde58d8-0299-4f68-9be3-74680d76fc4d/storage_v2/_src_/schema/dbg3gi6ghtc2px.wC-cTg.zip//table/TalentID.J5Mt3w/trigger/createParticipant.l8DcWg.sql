create definer = utoldtf78qili@`%` trigger createParticipant
    after insert
    on TalentID
    for each row
begin
        insert into Participants(Part_Talent_ID) values (new.TID_TalentID);
end;


create definer = utoldtf78qili@`%` trigger SASS_SCORE_MAX_100_UPDATE
    before update
    on Score_Assigned
    for each row
BEGIN
    IF NEW.SASS_Score > 100 THEN
        signal sqlstate '45000' set message_text = "Trying to SET score greater than 100";
    END IF;
end;


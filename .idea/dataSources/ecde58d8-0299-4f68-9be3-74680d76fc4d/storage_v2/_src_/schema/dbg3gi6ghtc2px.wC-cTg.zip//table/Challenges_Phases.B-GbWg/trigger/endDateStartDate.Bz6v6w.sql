create definer = utoldtf78qili@`%` trigger endDateStartDate
    before insert
    on Challenges_Phases
    for each row
begin
        if new.CPH_Start_Date > new.CPH_End_Date THEN
            signal sqlstate '45000' set message_text = 'Error, start_date greater than end_date';
        end if;
    end;


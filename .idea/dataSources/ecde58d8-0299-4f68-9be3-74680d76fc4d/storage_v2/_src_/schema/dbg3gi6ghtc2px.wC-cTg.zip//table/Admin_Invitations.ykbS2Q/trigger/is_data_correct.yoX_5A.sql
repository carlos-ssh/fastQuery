create definer = uwqxnypspa2bb@`%` trigger is_data_correct
    before insert
    on Admin_Invitations
    for each row
BEGIN

    IF((NEW.AI_InvitedBy IS NULL) OR (NEW.AI_AdminType='ORG' AND NEW.AI_Org_ID IS NULL) or ( (NEW.AI_AdminType='CHA' AND NEW.AI_Cha_ID IS NULL))) THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Datos incompletos', MYSQL_ERRNO = 400 ;
    END IF;

    IF(NEW.AI_AdminType='GA') THEN
        IF((EXISTS(select * from TalentID where TID_TalentID=NEW.AI_InvitedBy))=0 or ((SELECT TID_IsGAADMIN FROM TalentID WHERE TID_TalentID=NEW.AI_InvitedBy LIMIT 1)=0)) THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Sin autorización', MYSQL_ERRNO = 403 ;
        end if;
    END IF;

    IF(NEW.AI_AdminType='ORG') THEN
        IF (EXISTS(SELECT * FROM TalentID WHERE TID_TalentID=NEW.AI_InvitedBy)=0 OR ((SELECT TID_IsGAADMIN FROM TalentID WHERE TID_TalentID=NEW.AI_InvitedBy LIMIT 1)=0) AND 
           (EXISTS(SELECT * FROM Admin_Org WHERE (AO_Org_ID=NEW.AI_Org_ID AND AO_TID_ID=NEW.AI_InvitedBy) OR (AO_Org_ID=(SELECT Org_ParentOrganizer FROM Organizers WHERE Org_ID=NEW.AI_Org_ID LIMIT 1) AND AO_TID_ID=new.AI_InvitedBy ) )=0  )) THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Sin autorización', MYSQL_ERRNO = 403 ;
        end if;
    END IF;

    IF(NEW.AI_AdminType='CHA') THEN
        IF (EXISTS(SELECT * FROM TalentID WHERE TID_TalentID=NEW.AI_InvitedBy)=0 OR ((SELECT TID_IsGAADMIN FROM TalentID WHERE TID_TalentID=NEW.AI_InvitedBy LIMIT 1)=0)
            AND  (EXISTS(SELECT * FROM Admin_Org WHERE (AO_Org_ID=(SELECT Cha_Organizer FROM Challenges WHERE Cha_ID=NEW.AI_Cha_ID LIMIT  1 ) AND AO_TID_ID=NEW.AI_InvitedBy ) OR (AO_Org_ID=(SELECT Org_ParentOrganizer FROM Challenges INNER JOIN Organizers O on Challenges.Cha_Organizer = O.Org_ID WHERE Cha_ID=NEW.AI_Cha_ID ) AND AO_TID_ID=NEW.AI_InvitedBy))=0))  THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Sin autorización', MYSQL_ERRNO = 403 ;
        end if;
    END IF;
END;


create definer = uwqxnypspa2bb@`%` view Final_Score_by_PProject as
select `FS`.`SASS_PPRO_ID`     AS `SASS_PPRO_ID`,
       `P`.`PPRO_Title`        AS `PPRO_Title`,
       `P`.`PPRO_Image`        AS `PPRO_Image`,
       `FS`.`PPTSC_CPH_ID`     AS `PPTSC_CPH_ID`,
       `CP`.`CPH_Phase_Num`    AS `Current_phase`,
       sum(`FS`.`FINAL_SCORE`) AS `TOTAL`,
       `P`.`PPRO_RPA_ID`       AS `PPRO_RPA_ID`,
       `P`.`PPRO_Team_ID`      AS `PPRO_Team_ID`
from ((`dbg3gi6ghtc2px`.`Final_Score_by_PPTSC` `FS` left join `dbg3gi6ghtc2px`.`Participant_Project` `P`
       on ((`FS`.`SASS_PPRO_ID` = `P`.`PPRO_ID`))) left join `dbg3gi6ghtc2px`.`Challenges_Phases` `CP`
      on ((`P`.`PPRO_Current_CPH_ID` = `CP`.`CPH_ID`)))
group by `FS`.`SASS_PPRO_ID`, `FS`.`PPTSC_CPH_ID`;

-- comment on column Final_Score_by_PProject.PPRO_Team_ID not supported: PENDIENTE


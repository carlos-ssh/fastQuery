create definer = uwqxnypspa2bb@`%` view Report_Mentors as
select `t`.`RM_ID`                AS `RM_ID`,
       `t`.`RM_Cha_ID`            AS `RM_Cha_ID`,
       `t`.`TID_Email`            AS `TID_Email`,
       `t`.`TIN_Last_Name`        AS `TIN_Last_Name`,
       `t`.`TIN_Name`             AS `TIN_Name`,
       `t`.`Ment_Mode`            AS `Ment_Mode`,
       `t`.`Ment_JudgeLevel`      AS `Ment_JudgeLevel`,
       `t`.`Ment_Photo`           AS `Ment_Photo`,
       `t`.`Ment_Job`             AS `Ment_Job`,
       `t`.`Ment_Specialist`      AS `Ment_Specialist`,
       `t`.`Ment_Group`           AS `Ment_Group`,
       `t`.`Ment_Bio`             AS `Ment_Bio`,
       `t`.`Additional_Info_JSON` AS `Additional_Info_JSON`,
       if((`CC`.`CCA_Name` is not null),
          concat('[', group_concat(json_object('CCA_Name', `CC`.`CCA_Name`, 'CCA_ID', `CC`.`CCA_ID`) separator ','),
                 ']'), NULL)      AS `Categories_JSON`
from ((((select `dbg3gi6ghtc2px`.`Registered_Mentors`.`RM_ID`           AS `RM_ID`,
                `dbg3gi6ghtc2px`.`Registered_Mentors`.`RM_Cha_ID`       AS `RM_Cha_ID`,
                `TI`.`TID_Email`                                        AS `TID_Email`,
                `TII`.`TIN_Name`                                        AS `TIN_Name`,
                `TII`.`TIN_Last_Name`                                   AS `TIN_Last_Name`,
                `dbg3gi6ghtc2px`.`Registered_Mentors`.`RM_Bio`          AS `Ment_Bio`,
                `dbg3gi6ghtc2px`.`Registered_Mentors`.`RM_Group`        AS `Ment_Group`,
                `dbg3gi6ghtc2px`.`Registered_Mentors`.`RM_Job`          AS `Ment_Job`,
                `dbg3gi6ghtc2px`.`Registered_Mentors`.`RM_Photo`        AS `Ment_Photo`,
                `dbg3gi6ghtc2px`.`Registered_Mentors`.`RM_Specialist`   AS `Ment_Specialist`,
                `dbg3gi6ghtc2px`.`Registered_Mentors`.`Ment_JudgeLevel` AS `Ment_JudgeLevel`,
                `dbg3gi6ghtc2px`.`Registered_Mentors`.`Ment_Mode`       AS `Ment_Mode`,
                if((`CMAI`.`CMAI_Name` is not null), concat('[', group_concat(
                        json_object(if(isnull(`CMAI`.`CMAI_Name`), '', `CMAI`.`CMAI_Name`), `MAI`.`MAI_FieldValue`)
                        separator ','), ']'), NULL)                     AS `Additional_Info_JSON`
         from ((((`dbg3gi6ghtc2px`.`Registered_Mentors` join `dbg3gi6ghtc2px`.`TalentID` `TI`
                  on ((`dbg3gi6ghtc2px`.`Registered_Mentors`.`RM_Talent_ID` =
                       `TI`.`TID_TalentID`))) join `dbg3gi6ghtc2px`.`TalentId_Info` `TII`
                 on ((`TI`.`TID_TalentID` = `TII`.`TIN_TID_ID`))) left join `dbg3gi6ghtc2px`.`Mentor_Aditional_Info` `MAI`
                on ((`dbg3gi6ghtc2px`.`Registered_Mentors`.`RM_ID` = `MAI`.`MAI_RM_ID`))) left join `dbg3gi6ghtc2px`.`Challenge_Mentor_Aditional_Info` `CMAI`
               on ((`MAI`.`MAI_CMAI_ID` = `CMAI`.`CMAI_ID`)))
         group by `dbg3gi6ghtc2px`.`Registered_Mentors`.`RM_ID`)) `t` left join `dbg3gi6ghtc2px`.`Mentor_Categories` `MC`
       on ((`MC`.`MC_RM_ID` = `t`.`RM_ID`))) left join `dbg3gi6ghtc2px`.`Challenge_Categories` `CC`
      on ((`MC`.`MC_CCA_ID` = `CC`.`CCA_ID`)))
group by `t`.`RM_ID`;

-- comment on column Report_Mentors.Ment_Mode not supported: ¿Para saber si da mentorias especializadas?


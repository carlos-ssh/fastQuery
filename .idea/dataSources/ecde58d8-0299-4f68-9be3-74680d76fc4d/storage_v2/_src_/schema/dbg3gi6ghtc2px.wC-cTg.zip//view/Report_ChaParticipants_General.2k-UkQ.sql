create definer = uwqxnypspa2bb@`%` view Report_ChaParticipants_General as
select `RPA`.`RPA_ID`                      AS `RPA_ID`,
       `RPA`.`RPA_Cha_ID`                  AS `Cha_ID`,
       `Part`.`Part_ID`                    AS `Participant ID`,
       `TII`.`TIN_Name`                    AS `Nombre`,
       `TII`.`TIN_Last_Name`               AS `Apellido`,
       `TID`.`TID_Email`                   AS `Email`,
       `TII`.`TIN_Username`                AS `Usuario`,
       `RPA`.`RPA_Reg_Date`                AS `RPA_Reg_Date`,
       concat('[', group_concat(json_object(if(isnull(`CAI`.`CAI_Name`), '', `CAI`.`CAI_Name`),
                                            if(isnull(`PAI`.`PAI_FieldValue`), '', `PAI`.`PAI_FieldValue`)) separator
                                ','), ']') AS `Part_Info_JSON`
from (((((`dbg3gi6ghtc2px`.`Registered_Participants` `RPA` join `dbg3gi6ghtc2px`.`Participants` `Part`
          on ((`Part`.`Part_ID` = `RPA`.`RPA_Part_ID`))) join `dbg3gi6ghtc2px`.`TalentID` `TID`
         on ((`TID`.`TID_TalentID` = `Part`.`Part_Talent_ID`))) join `dbg3gi6ghtc2px`.`TalentId_Info` `TII`
        on ((`TID`.`TID_TalentID` = `TII`.`TIN_TID_ID`))) left join `dbg3gi6ghtc2px`.`Participant_Aditional_Info` `PAI`
       on ((`PAI`.`PAI_RP_ID` = `RPA`.`RPA_ID`))) left join `dbg3gi6ghtc2px`.`Challenge_Aditional_Info` `CAI`
      on ((`PAI`.`PAI_CAI_ID` = `CAI`.`CAI_ID`)))
group by `RPA`.`RPA_Cha_ID`, `Part`.`Part_ID`;


create definer = utoldtf78qili@`%` trigger TeamInvitation
    after insert
    on Reg_Team_Participants
    for each row
BEGIN
    INSERT INTO Participant_Notification(PNO_Part_ID, PNO_Action, PNO_Message)
    VALUES (
               NEW.RTP_Part_ID
           ,CONCAT("challenge_page?cha_id=",NEW.RTP_Cha_ID)
           ,CONCAT("Has sido invitado por "
                   ,(SELECT CONCAT(TI.TIN_Name,' ',TI.TIN_Last_Name) as Name
                     FROM Participants P
                              INNER JOIN TalentId_Info TI on P.Part_Talent_ID = TI.TIN_TID_ID
                     WHERE Part_ID = NEW.RTP_Part_ID LIMIT 1)
                   ," al challenge "
                   ,(SELECT Cha_Name FROM Challenges WHERE Cha_ID = NEW.RTP_Cha_ID LIMIT 1)
                   )
           );
end;

